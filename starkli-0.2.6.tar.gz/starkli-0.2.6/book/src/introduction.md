# Welcome to Starkli

Starkli is a command line tool for interacting with [Starknet](https://starknet.io/), powered by [starknet-rs](https://github.com/xJonathanLEI/starknet-rs).

Starkli allows you to query Starknet and make transactions with ease. It's fast, easy to install, and intuitive to use.
